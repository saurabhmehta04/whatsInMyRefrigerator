<?php
 error_reporting(0);

 
 $arg1 = $_GET["arg1"];
 $arg2 = $_GET["arg2"];
 $arg3 = $_GET["arg3"];
 
// Create connection
$con=mysqli_connect("localhost","root","root","login");
 
// Check connection
if (mysqli_connect_errno())
{
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

// if($arg1!=[] and $arg2!=[] and $arg3==[]){
// $sql = "SELECT itemname,qty,category,edate,fav FROM inventoryitems WHERE username = '". $arg1 . "' AND fridgename = '". $arg2 ."'";
// }
// else if($arg1!=[] and $arg2!=[] and $arg3!=[] and $arg4!=[] and $arg5!=[] and $arg6!=[] and $arg7!=[]){
// $sql = "INSERT INTO inventoryitems(username,fridgename,itemname,qty,category,edate,fav) VALUES ('" . $arg1 ."','" . $arg2 ."','". $arg3 . "','". $arg4 ."','" . $arg5 ."','" . $arg6 . "','" . $arg7 . "')";
// }
// else{
// $sql = "SELECT * FROM inventoryitems";
// }
 if($arg1!=[] and $arg2!=[] and $arg3!=[]){
$sql = "INSERT INTO favourite(username,itemname,category) VALUES ('" . $arg1 . "','" . $arg2 . "','" . $arg3 . "')";
}else{
$sql = "SELECT itemname,category FROM favourite WHERE username ='" . $arg1 . "'";
}
//echo $sql;
if ($result = mysqli_query($con, $sql))
{
	// If so, then create a results array and a temporary one
	// to hold the data
	$resultArray = array();
	$tempArray = array();
 
	// Loop through each row in the result set
	while($row = $result->fetch_object())
	{
		// Add each row into our results array
		$tempArray = $row;
	    array_push($resultArray, $tempArray);
	}
 
	// Finally, encode the array to JSON and output the results
	echo json_encode($resultArray);
}
 
// Close connections
mysqli_close($con);
?>
